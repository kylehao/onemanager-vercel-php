OneManagerPath=`cd $(dirname $0);pwd -P`
cd ${OneManagerPath}
chmod 666 .data/config.php
